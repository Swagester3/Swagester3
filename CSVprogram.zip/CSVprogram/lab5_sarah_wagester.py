"""Sarah Wagester
SDEV 300 6981
This program allows a user to load one of two CSV files and perform histogram analysis
and plots for select variables on the datasets"""

import csv
import pandas as pd
import matplotlib.pyplot as plt

FILE_WITH_HOUSING_DATA = "Housing.csv"  # establishes path for housing csv
FILE_WITH_POP_DATA = "PopChange.csv"  # establishes path for population csv


def display_menu():
    """This function displays the menu"""
    print("\nSelect the file you want to analyze:")
    print("1. Population Data")
    print("2. Housing Data")
    print("3. Exit the Program")


def load_csv(file):
    """Function to load files"""
    file_path = file
    with open(file_path, "r", encoding="utf-8") as csv_file:
        try:  # try block for reading file selection
            csv_reader = csv.reader(csv_file)
            return csv_reader
        except FileNotFoundError:  # error if file is not found
            print("This file was not found")
        return load_csv(csv_file)


def population_column():
    """Function to choose population column"""
    column = ""  # establishes column variable
    while True:  # loop for column section
        print("\nSelect the column you want to analyze:")
        print("a. Pop Apr 1")
        print("b. Pop Jul 1")
        print("c. Change Pop")
        print("d. Exit Column")

        try:  # try block for column choice
            column_analyze = input()
            if column_analyze == "d":  # choice to exit the column menu
                print("You will now exit the column menu, thank you.")
                break
            if column_analyze == "a":  # sets column choice to reference variable
                column = "Pop Apr 1"
                break
            if column_analyze == "b":  # sets column choice to reference variable
                column = "Pop Jul 1"
                break
            if column_analyze == "c":  # sets column choice to reference variable
                column = "Change Pop"
                break
            raise ValueError()  # raises a value error if input is invalid
        except (ValueError, KeyboardInterrupt):  # displays error message
            print("You did not choose a correct selection, please try again.")
    return column


def housing_column():
    """Function to choose housing column"""
    column = ""  # establishes column variable
    while True:  # loop for column section
        print("\nSelect the column you want to analyze:")
        print("a. Age")
        print("b. Bedrooms")
        print("c. Built")
        print("d. Rooms")
        print("e. Utility")
        print("f. Exit column")
        try:  # try block for column choice
            column_analyze = input()
            if column_analyze == "f":  # choice to exit the column menu
                print("You will now exit the column menu, thank you.")
                break
            if column_analyze == "a":  # sets column choice to reference variable
                column = "AGE"
                break
            if column_analyze == "b":  # sets column choice to reference variable
                column = "BEDRMS"
                break
            if column_analyze == "c":  # sets column choice to reference variable
                column = "BUILT"
                break
            if column_analyze == "d":  # sets column choice to reference variable
                column = "ROOMS"
                break
            if column_analyze == "e":  # sets column choice to reference variable
                column = "UTILITY"
                break
            raise ValueError()  # raises a value error if input is invalid
        except (ValueError, KeyboardInterrupt):  # displays error message
            print("You did not choose a correct selection, please try again.")
    return column


def display_data(file, column):
    """This function displays the data requested to the user"""
    d_f = pd.read_csv(file)  # reads data
    data = d_f[column]  # establishes data
    mean = data.mean()  # calculates mean
    max_value = data.max()  # calculates max
    min_value = data.min()  # calculates min
    count = data.count()  # counts
    deviation = data.std()  # calculates standard deviation

    print(f"\nYou selected {column}")
    print("\nThe statistics for this column are:")
    print(f"Count = {count}")  # displays count
    print(f"Mean = {mean}")  # displays mean
    print(f"Standard Deviation = {deviation}")  # displays standard deviation
    print(f"Min = {min_value}")  # displays min
    print(f"Max = {max_value}")  # displays max
    return data


def histogram_analysis(column, data):
    """This function creates the histogram"""
    print("\nThe Histogram of this column is now displayed.")
    plt.hist(data, bins=20)
    plt.xlabel(column)
    plt.ylabel("Data")
    plt.title(f"Histogram of {column}")
    plt.show()


def main():
    """This runs the main program"""
    print("\n*****Welcome to the Python Data Analysis App*****")
    display_menu()
    option = 0
    try:  # try block for option
        option = int(input())
    except ValueError:  # displays value error message
        print("\nThat is not a correct option, please enter an integer 1, 2 or 3.")
    while option != 3:  # loop for file option
        if option == 1:  # block for option 1, population data
            file = FILE_WITH_POP_DATA  # sets CSV to use
            csv_file = load_csv(file)  # runs function to fine file
            if csv_file is not None:
                while True:  # loop for column validation
                    column = population_column()
                    if not column:
                        break
                    data = display_data(file, column)
                    histogram_analysis(column, data)
        elif option == 2:  # block for option 2, housing data
            file = FILE_WITH_HOUSING_DATA  # sets CSV to use
            csv_file = load_csv(file)  # runs function to fine file
            if csv_file is not None:
                while True:  # loop for column validatio
                    column = housing_column()
                    if not column:
                        break
                    data = display_data(file, column)
                    histogram_analysis(column, data)
        else:
            print("\nThis is an invalid option, please try again.")
        display_menu()
        try:  # try block for option reprompt
            option = int(input())
        except ValueError:  # displays error message to user
            print("\nThat is not a correct option, please enter an integer 1, 2 or 3.")
    print("*****Thank you for using the Data Analysis App. Goodbye!*****")  # displays goodbye


main()
